# Contributor Covenant Code of Conduct

## Our pledge

We pledge to make participation in this project a harassment-free experience for everyone.

## Our standards

Be respectful, focus criticism on technical work, protect private information, and avoid publishing credentials or personal data.

## Enforcement

Project maintainers may remove abusive content and restrict participation when conduct threatens contributors or users. Serious concerns may be reported privately through GitHub.

This concise policy is based on the principles of Contributor Covenant 2.1.
