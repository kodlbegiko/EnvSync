# Security policy

## Supported versions

The latest tagged release is supported with security fixes.

## Reporting a vulnerability

Open a private GitHub security advisory for vulnerabilities. Do not include real credentials or private `.env` content.

## Security boundary

EnvSync reads configured source files and example files only. It does not execute target code, import JavaScript configuration, read real `.env` files, upload data, or provide a complete secret-scanning guarantee. See `docs/security-model.md`.
