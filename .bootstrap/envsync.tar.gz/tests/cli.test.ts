import { mkdtemp, readFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { executeCli } from "../src/cli.js";
import { fixture } from "./helpers.js";

function capture() {
  let stdout = "";
  let stderr = "";
  return {
    io: {
      stdout: (value: string) => { stdout += value; },
      stderr: (value: string) => { stderr += value; },
    },
    stdout: () => stdout,
    stderr: () => stderr,
  };
}

describe.sequential("CLI", () => {
  const original = process.cwd();
  beforeEach(() => process.chdir(original));
  afterEach(() => process.chdir(original));

  it("runs check by default", async () => {
    process.chdir(fixture("valid-node-project"));
    const output = capture();
    expect(await executeCli([], output.io)).toBe(0);
    expect(output.stdout()).toContain("Result: PASS");
  });

  it("accepts a positional target without check", async () => {
    const output = capture();
    expect(await executeCli([fixture("valid-node-project")], output.io)).toBe(0);
  });

  it("accepts the explicit check command", async () => {
    const output = capture();
    expect(await executeCli(["check", fixture("missing-from-example")], output.io)).toBe(1);
  });

  it("renders JSON", async () => {
    const output = capture();
    const code = await executeCli([fixture("valid-node-project"), "--format", "json"], output.io);
    expect(code).toBe(0);
    expect(JSON.parse(output.stdout()).passed).toBe(true);
  });

  it("writes Markdown output", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-cli-output-"));
    const outputFile = path.join(root, "report.md");
    const output = capture();
    const code = await executeCli([
      fixture("valid-node-project"),
      "--format",
      "markdown",
      "--output",
      outputFile,
    ], output.io);
    expect(code).toBe(0);
    expect(await readFile(outputFile, "utf8")).toContain("# EnvSync report");
    expect(output.stdout()).toBe("");
  });

  it("supports warnings as errors", async () => {
    const output = capture();
    expect(await executeCli([fixture("unused-example-variable"), "--warnings-as-errors"], output.io)).toBe(1);
  });

  it("returns exit code 2 for config errors", async () => {
    process.chdir(fixture("malformed-config"));
    const output = capture();
    expect(await executeCli([], output.io)).toBe(2);
    expect(output.stderr()).toContain("EnvSync error");
  });

  it("returns exit code 2 for invalid arguments", async () => {
    const output = capture();
    expect(await executeCli(["--not-an-option"], output.io)).toBe(2);
  });

  it("prints version", async () => {
    const output = capture();
    expect(await executeCli(["--version"], output.io)).toBe(0);
    expect(output.stdout()).toContain("0.1.0");
  });

  it("initializes a project", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-cli-init-"));
    const output = capture();
    expect(await executeCli(["init", root], output.io)).toBe(0);
    expect(output.stdout()).toContain("envsync.config.json");
  });
});
