import { mkdtemp, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { defaultConfig, findConfig, loadConfig } from "../src/config.js";
import { EnvSyncError } from "../src/errors.js";
import { fixture } from "./helpers.js";

describe("configuration", () => {
  it("creates a deterministic default config", () => {
    const config = defaultConfig("/tmp/app");
    expect(config.projects[0]).toMatchObject({ name: "app", root: "/tmp/app", preset: "node" });
    expect(config.severity["missing-from-example"]).toBe("error");
  });

  it("returns no auto config when absent", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-none-"));
    await expect(findConfig(root)).resolves.toBeUndefined();
  });

  it("finds envsync.config.json first", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-first-"));
    await writeFile(path.join(root, ".envsync.json"), '{"projects":[{"name":"dot"}]}');
    await writeFile(path.join(root, "envsync.config.json"), '{"projects":[{"name":"main"}]}');
    await expect(findConfig(root)).resolves.toBe(path.join(root, "envsync.config.json"));
  });

  it("finds .envsync.json as fallback", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-dot-"));
    await writeFile(path.join(root, ".envsync.json"), '{"projects":[{"name":"dot"}]}');
    await expect(findConfig(root)).resolves.toBe(path.join(root, ".envsync.json"));
  });

  it("rejects an explicit missing config", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-missing-"));
    await expect(loadConfig(root, ".", "missing.json")).rejects.toBeInstanceOf(EnvSyncError);
  });

  it("rejects malformed JSON", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-json-"));
    await writeFile(path.join(root, "envsync.config.json"), "{");
    await expect(loadConfig(root)).rejects.toThrow("Cannot parse JSON configuration");
  });

  it("rejects unknown fields with a field path", async () => {
    await expect(loadConfig(fixture("malformed-config"))).rejects.toThrow("Unrecognized key");
  });

  it("rejects conflicting required and optional variables", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-conflict-"));
    await writeFile(
      path.join(root, "envsync.config.json"),
      JSON.stringify({ projects: [{ name: "app", required: ["A"], optional: ["A"] }] }),
    );
    await expect(loadConfig(root)).rejects.toThrow("appears in both required and optional");
  });

  it("rejects invalid variable names", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-name-"));
    await writeFile(
      path.join(root, "envsync.config.json"),
      JSON.stringify({ projects: [{ name: "app", required: ["1BAD"] }] }),
    );
    await expect(loadConfig(root)).rejects.toThrow("Invalid environment variable name");
  });

  it("merges custom severity with defaults", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-severity-"));
    await writeFile(
      path.join(root, "envsync.config.json"),
      JSON.stringify({ projects: [{ name: "app" }], severity: { "missing-from-example": "warning" } }),
    );
    const { config } = await loadConfig(root);
    expect(config.severity["missing-from-example"]).toBe("warning");
    expect(config.severity["possible-secret-in-example"]).toBe("error");
  });

  it("resolves project roots relative to config", async () => {
    const root = fixture("monorepo-separated-projects");
    const { config } = await loadConfig(root);
    expect(config.projects[0]?.root).toBe(path.join(root, "apps", "web"));
  });

  it("rejects project root traversal by default", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "envsync-config-traversal-"));
    await writeFile(
      path.join(root, "envsync.config.json"),
      JSON.stringify({ projects: [{ name: "app", root: "../outside" }] }),
    );
    await expect(loadConfig(root)).rejects.toThrow("Path escapes project root");
  });

  it("allows project root traversal only with opt-in", async () => {
    const parent = await mkdtemp(path.join(os.tmpdir(), "envsync-config-optin-"));
    const root = path.join(parent, "config");
    await import("node:fs/promises").then(({ mkdir }) => mkdir(root));
    await writeFile(
      path.join(root, "envsync.config.json"),
      JSON.stringify({ projects: [{ name: "app", root: "..", allowOutsideRoot: true }] }),
    );
    const { config } = await loadConfig(root);
    expect(config.projects[0]?.root).toBe(parent);
  });
});
