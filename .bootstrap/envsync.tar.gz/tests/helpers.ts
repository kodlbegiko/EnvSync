import path from "node:path";
import { fileURLToPath } from "node:url";
import type { ProjectConfig } from "../src/types.js";

const here = path.dirname(fileURLToPath(import.meta.url));
export const fixtures = path.join(here, "fixtures");
export const fixture = (name: string): string => path.join(fixtures, name);

export function project(overrides: Partial<ProjectConfig> = {}): ProjectConfig {
  return {
    name: "app",
    root: ".",
    include: ["**/*.{js,jsx,ts,tsx,mjs,cjs}"],
    exclude: [],
    exampleFiles: [".env.example"],
    preset: "node",
    required: [],
    optional: [],
    ignore: [],
    allowOutsideRoot: false,
    maxFileSizeBytes: 1_048_576,
    ...overrides,
  };
}
