import { describe, expect, it } from "vitest";
import { DEFAULT_SEVERITY } from "../src/constants.js";
import { evaluateProject, sortFindings } from "../src/rules.js";
import type { EnvUsage, ExampleEntry, Finding } from "../src/types.js";
import { project } from "./helpers.js";

const usage = (variable: string | undefined, overrides: Partial<EnvUsage> = {}): EnvUsage => ({
  ...(variable ? { variable } : {}),
  syntax: "process.env",
  file: "src/index.ts",
  line: 1,
  column: 1,
  static: variable !== undefined,
  clientFile: false,
  ...overrides,
});
const entry = (key: string, value = ""): ExampleEntry => ({ key, value, file: ".env.example", line: 1 });

describe("evaluateProject", () => {
  it("reports missing statically used variables", () => {
    const findings = evaluateProject(project(), [usage("DATABASE_URL")], [], DEFAULT_SEVERITY);
    expect(findings[0]).toMatchObject({ ruleId: "missing-from-example", variable: "DATABASE_URL", severity: "error" });
  });

  it("reports required variables without source usage", () => {
    const findings = evaluateProject(project({ required: ["DATABASE_URL"] }), [], [], DEFAULT_SEVERITY);
    expect(findings[0]?.ruleId).toBe("missing-from-example");
  });

  it("does not report documented required variables", () => {
    const findings = evaluateProject(project({ required: ["DATABASE_URL"] }), [], [entry("DATABASE_URL")], DEFAULT_SEVERITY);
    expect(findings).toHaveLength(0);
  });

  it("reports unused documented variables", () => {
    const findings = evaluateProject(project(), [], [entry("OLD_FLAG")], DEFAULT_SEVERITY);
    expect(findings[0]).toMatchObject({ ruleId: "unused-example-variable", severity: "warning" });
  });

  it("allows optional documented variables", () => {
    const findings = evaluateProject(project({ optional: ["SENTRY_DSN"] }), [], [entry("SENTRY_DSN")], DEFAULT_SEVERITY);
    expect(findings).toHaveLength(0);
  });

  it("ignores configured variables", () => {
    const findings = evaluateProject(project({ ignore: ["CI"] }), [usage("CI")], [entry("CI")], DEFAULT_SEVERITY);
    expect(findings).toHaveLength(0);
  });

  it("reports dynamic access", () => {
    const findings = evaluateProject(project(), [usage(undefined)], [], DEFAULT_SEVERITY);
    expect(findings[0]).toMatchObject({ ruleId: "dynamic-env-access", file: "src/index.ts" });
  });

  it("warns on sensitive Next.js public variables", () => {
    const findings = evaluateProject(
      project({ preset: "next" }),
      [usage("NEXT_PUBLIC_API_TOKEN")],
      [entry("NEXT_PUBLIC_API_TOKEN", "example-token")],
      DEFAULT_SEVERITY,
    );
    expect(findings.some((finding) => finding.ruleId === "possible-public-secret")).toBe(true);
  });

  it("warns on sensitive Vite public variables", () => {
    const findings = evaluateProject(
      project({ preset: "vite" }),
      [usage("VITE_PASSWORD", { syntax: "import.meta.env" })],
      [entry("VITE_PASSWORD", "example-password")],
      DEFAULT_SEVERITY,
    );
    expect(findings.some((finding) => finding.ruleId === "possible-public-secret")).toBe(true);
  });

  it("warns when a server variable is used in a Next.js client file", () => {
    const findings = evaluateProject(
      project({ preset: "next" }),
      [usage("DATABASE_URL", { clientFile: true })],
      [entry("DATABASE_URL", "postgres://example.invalid")],
      DEFAULT_SEVERITY,
    );
    expect(findings.some((finding) => finding.ruleId === "server-variable-in-client")).toBe(true);
  });

  it("does not warn for a server variable in a server file", () => {
    const findings = evaluateProject(
      project({ preset: "next" }),
      [usage("DATABASE_URL")],
      [entry("DATABASE_URL", "postgres://example.invalid")],
      DEFAULT_SEVERITY,
    );
    expect(findings).toHaveLength(0);
  });

  it("reports secret-shaped example values without including the value", () => {
    const secret = "ghp_abcdefghijklmnopqrstuvwxyz1234567890AB";
    const findings = evaluateProject(project(), [usage("GITHUB_TOKEN")], [entry("GITHUB_TOKEN", secret)], DEFAULT_SEVERITY);
    const finding = findings.find((item) => item.ruleId === "possible-secret-in-example");
    expect(finding?.message).not.toContain(secret);
    expect(finding?.severity).toBe("error");
  });

  it("applies severity overrides", () => {
    const findings = evaluateProject(
      project(),
      [usage("MISSING")],
      [],
      { ...DEFAULT_SEVERITY, "missing-from-example": "info" },
    );
    expect(findings[0]?.severity).toBe("info");
  });
});

describe("sortFindings", () => {
  it("sorts by severity, project, rule, variable, file, and line", () => {
    const findings: Finding[] = [
      { ruleId: "z", severity: "warning", message: "z", file: "b", line: 2 },
      { ruleId: "a", severity: "error", message: "a", file: "a", line: 1 },
      { ruleId: "b", severity: "warning", message: "b", file: "a", line: 1 },
    ];
    expect(sortFindings(findings).map((finding) => finding.ruleId)).toEqual(["a", "b", "z"]);
  });

  it("does not mutate input", () => {
    const findings: Finding[] = [
      { ruleId: "b", severity: "warning", message: "b" },
      { ruleId: "a", severity: "error", message: "a" },
    ];
    sortFindings(findings);
    expect(findings[0]?.ruleId).toBe("b");
  });
});
