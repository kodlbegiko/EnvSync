# Limitations

- v0.1.0 parses JavaScript and TypeScript-family source files only.
- Computed names such as `process.env[prefix + "_TOKEN"]` are reported but cannot be resolved.
- Destructuring (`const { KEY } = process.env`) and framework-specific wrappers are not yet interpreted.
- Unused example variables may be consumed by shell scripts, Docker, CI, unsupported languages, or external services.
- Client/server classification is intentionally conservative: Next.js uses the `"use client"` directive and public prefixes; Vite uses `VITE_`.
- Secret heuristics can produce false positives and false negatives.
- Projects are isolated; cross-workspace shared-variable semantics require explicit future design.
- The npm package is not claimed as publicly published until registry publication is independently verified.
