# Configuration

EnvSync loads `envsync.config.json`, then `.envsync.json`. Use `--config <file>` for an explicit path. JavaScript configuration is intentionally unsupported.

```json
{
  "$schema": "./node_modules/envsync/schema.json",
  "projects": [
    {
      "name": "web",
      "root": "apps/web",
      "include": ["src/**/*.{js,jsx,ts,tsx,mjs,cjs}"],
      "exclude": ["generated/**"],
      "exampleFiles": [".env.example"],
      "preset": "next",
      "required": ["DATABASE_URL"],
      "optional": ["SENTRY_DSN"],
      "ignore": ["NODE_ENV", "CI"]
    }
  ],
  "severity": {
    "missing-from-example": "error",
    "unused-example-variable": "warning"
  }
}
```

`required` variables must be documented even when no supported source usage is found. `optional` variables may be documented without an unused warning. `ignore` variables are excluded from missing and unused decisions. A variable cannot appear in conflicting groups.

Project roots and configured files are confined to their project root by default. `allowOutsideRoot` is an explicit trust-boundary override. Source files larger than `maxFileSizeBytes` are skipped with a warning.
