# Rules

| Rule | Default | Meaning |
| --- | --- | --- |
| `missing-from-example` | error | A required or statically used variable is absent from configured example files. |
| `unused-example-variable` | warning | A documented variable has no supported source usage. External usage may still exist. |
| `dynamic-env-access` | warning | A computed access cannot be mapped to one static name. |
| `possible-public-secret` | warning | A public-prefixed variable has a sensitive-looking name. This is heuristic only. |
| `server-variable-in-client` | warning | A Next.js client file references a non-public `process.env` variable. |
| `possible-secret-in-example` | error | An example value resembles a credential. The value is never emitted. |
| `duplicate-example-key` | warning | An example file defines the same key more than once. |
| `invalid-example-key` | warning | An example line or key is invalid. |
| `source-parse-error` | warning | TypeScript reported source syntax errors; scanning may be incomplete. |
| `skipped-large-file` | warning | A source file exceeded the configured size limit. |
| `unsafe-path` | error | A file violated the path or symlink safety policy. |
