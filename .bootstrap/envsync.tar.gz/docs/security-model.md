# Security model

EnvSync is local-first and deterministic. It performs filesystem reads and static parsing only.

## Guarantees

- It does not execute, `require`, or import scanned project code.
- It accepts data-only JSON configuration and never loads JavaScript config.
- It does not intentionally read `.env`, `.env.local`, or other real secret stores.
- It does not upload files, names, findings, or telemetry.
- It refuses configured path traversal by default and does not follow source symlinks.
- Reports contain variable names and locations, never example values.
- Large files are skipped under a configurable limit.

## Non-guarantees

Secret detection is heuristic. A warning is not proof of exposure, and absence of a warning is not proof of safety. EnvSync is not a SAST suite or credential scanner.
